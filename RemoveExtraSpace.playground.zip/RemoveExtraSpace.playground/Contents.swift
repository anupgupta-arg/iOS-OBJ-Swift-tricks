//: Playground - noun: a place where people can play

import UIKit

var str = "        Hello,                   playground            "

func removeWhiteSpaces( _ text:String ) -> String {
    
    var result:String = ""
    
    var prevChar = " " // white space
    for char in text {
        
        let currentChar = String( char )
        
        if !( prevChar == " " && currentChar == prevChar ) {
            
            result.append( currentChar )
        }
        
        prevChar = currentChar
    }
    
    return result
}

removeWhiteSpaces(str)


